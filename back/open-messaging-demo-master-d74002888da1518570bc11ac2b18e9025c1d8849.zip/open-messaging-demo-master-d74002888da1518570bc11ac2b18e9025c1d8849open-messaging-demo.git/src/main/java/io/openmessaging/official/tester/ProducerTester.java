package io.openmessaging.official.tester;

public class ProducerTester {


    public static void main(String[] args) {
        System.out.println("This is demo tester just for check");
    }
}
