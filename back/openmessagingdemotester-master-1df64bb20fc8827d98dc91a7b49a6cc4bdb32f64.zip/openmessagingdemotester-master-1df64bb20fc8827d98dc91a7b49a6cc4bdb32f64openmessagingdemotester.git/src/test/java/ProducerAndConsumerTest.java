import io.openmessaging.tester.ConsumerTester;
import io.openmessaging.tester.ProducerTester;

public class ProducerAndConsumerTest {


    public static void main(String[] args) throws Exception {
        ProducerTester.main(null);
        ConsumerTester.main(null);
    }
}
